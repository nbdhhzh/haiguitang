// OpenRouter API 配置
const OPENROUTER_API_KEY = "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";
const OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions";
const DEFAULT_MODEL = "deepseek/deepseek-chat-v3-0324:free";
